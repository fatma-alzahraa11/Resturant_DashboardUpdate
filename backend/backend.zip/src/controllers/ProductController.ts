import Product from '../models/Product';
import Category from '../models/Category';
import { Request, Response } from 'express';

export default {
  // Create a new product
  create: async (req: any, res: any) => {
    try {
      const { restaurantId, categoryId, name, description, price, ingredients, images, allergens, nutritionalInfo, availability, isNewItem, isPopular, isVegetarian, isVegan, isGlutenFree, isSpicy, preparationTime, sortOrder } = req.body;

      // Validate required fields
      if (!restaurantId || !categoryId || !name || !description || price === undefined) {
        return res.status(400).json({ 
          error: 'Missing required fields',
          details: 'restaurantId, categoryId, name, description, and price are required'
        });
      }

      // Validate category exists
      const category = await Category.findById(categoryId);
      if (!category) {
        return res.status(404).json({ error: 'Category not found' });
      }

      // Validate price
      if (price < 0) {
        return res.status(400).json({ error: 'Price cannot be negative' });
      }

      // Helper function to normalize ingredients
      const normalizeIngredients = (ingredients: any): string[] => {
        if (Array.isArray(ingredients)) {
          return ingredients;
        }
        if (ingredients && typeof ingredients === 'object') {
          // If it's an object with language keys, use the first available array
          if (ingredients.en && Array.isArray(ingredients.en)) return ingredients.en;
          if (ingredients.ar && Array.isArray(ingredients.ar)) return ingredients.ar;
          if (ingredients.de && Array.isArray(ingredients.de)) return ingredients.de;
        }
        return [];
      };

      // Create product with proper structure
      const productData = {
        restaurantId,
        categoryId,
        name: {
          en: name.en || name,
          ar: name.ar || name,
          de: name.de || name
        },
        description: {
          en: description.en || description,
          ar: description.ar || description,
          de: description.de || description
        },
        price,
        ingredients: normalizeIngredients(ingredients),
        images: images || [],
        allergens: allergens || [],
        nutritionalInfo: nutritionalInfo || {
          calories: 0,
          protein: 0,
          carbs: 0,
          fat: 0
        },
        availability: availability || {
          isAvailable: true,
          stockQuantity: null,
          lowStockThreshold: null
        },
        isNewItem: isNewItem || false,
        isPopular: isPopular || false,
        isVegetarian: isVegetarian || false,
        isVegan: isVegan || false,
        isGlutenFree: isGlutenFree || false,
        isSpicy: isSpicy || false,
        preparationTime: preparationTime || 0,
        sortOrder: sortOrder || 0,
        viewCount: 0,
        orderCount: 0,
        rating: 0,
        totalReviews: 0
      };

      const product = new Product(productData);
      await product.save();

      // Update category product count
      await Category.findByIdAndUpdate(categoryId, {
        $inc: { productCount: 1 }
      });

      res.status(201).json({
        message: 'Product created successfully',
        product
      });
    } catch (err: any) {
      console.error('Product creation error:', err);
      
      if (err.name === 'ValidationError') {
        const validationErrors = Object.values(err.errors).map((error: any) => error.message);
        return res.status(400).json({ 
          error: 'Validation failed', 
          details: validationErrors 
        });
      }
      
      if (err.name === 'CastError') {
        return res.status(400).json({ 
          error: 'Invalid data format',
          details: [`Invalid format for field: ${err.path}`]
        });
      }
      
      res.status(500).json({ error: err.message });
    }
  },

  // List products with filtering and pagination
  list: async (req: any, res: any) => {
    try {
      const { 
        restaurantId, 
        categoryId, 
        search, 
        isAvailable, 
        isNewItem, 
        isPopular,
        isVegetarian,
        isVegan,
        page = 1, 
        limit = 20,
        sortBy = 'sortOrder',
        sortOrder = 'asc'
      } = req.query;

      // Build filter object
      const filter: any = {};
      
      if (restaurantId) filter.restaurantId = restaurantId;
      if (categoryId) filter.categoryId = categoryId;
      if (isAvailable !== undefined) filter['availability.isAvailable'] = isAvailable === 'true';
      if (isNewItem !== undefined) filter.isNewItem = isNewItem === 'true';
      if (isPopular !== undefined) filter.isPopular = isPopular === 'true';
      if (isVegetarian !== undefined) filter.isVegetarian = isVegetarian === 'true';
      if (isVegan !== undefined) filter.isVegan = isVegan === 'true';

      // Search functionality
      if (search) {
        filter.$or = [
          { 'name.en': { $regex: search, $options: 'i' } },
          { 'name.ar': { $regex: search, $options: 'i' } },
          { 'name.de': { $regex: search, $options: 'i' } },
          { 'description.en': { $regex: search, $options: 'i' } },
          { 'description.ar': { $regex: search, $options: 'i' } },
          { 'description.de': { $regex: search, $options: 'i' } }
        ];
      }

      // Pagination
      const skip = (Number(page) - 1) * Number(limit);
      
      // Sorting
      const sort: any = {};
      sort[sortBy as string] = sortOrder === 'desc' ? -1 : 1;

      const products = await Product.find(filter)
        .populate('categoryId', 'name')
        .sort(sort)
        .skip(skip)
        .limit(Number(limit));

      const total = await Product.countDocuments(filter);

      res.json({
        products,
        pagination: {
          page: Number(page),
          limit: Number(limit),
          total,
          pages: Math.ceil(total / Number(limit))
        }
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  },

  // Get product by ID
  get: async (req: any, res: any) => {
    try {
      const product = await Product.findById(req.params.id)
        .populate('categoryId', 'name')
        .populate('restaurantId', 'name');

      if (!product) {
        return res.status(404).json({ error: 'Product not found' });
      }

      // Increment view count
      await Product.findByIdAndUpdate(req.params.id, {
        $inc: { viewCount: 1 }
      });

      res.json(product);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  },

  // Update product
  update: async (req: any, res: any) => {
    try {
      const { 
        name, 
        description, 
        price, 
        ingredients, 
        images, 
        allergens, 
        nutritionalInfo, 
        availability, 
        isNewItem, 
        isPopular, 
        isVegetarian, 
        isVegan, 
        isGlutenFree, 
        isSpicy, 
        preparationTime, 
        sortOrder 
      } = req.body;

      // Validate price if provided
      if (price !== undefined && price < 0) {
        return res.status(400).json({ error: 'Price cannot be negative' });
      }

      // Build update object
      const updateData: any = {};
      
      if (name) {
        updateData.name = {
          en: name.en || name,
          ar: name.ar || name,
          de: name.de || name
        };
      }
      
      if (description) {
        updateData.description = {
          en: description.en || description,
          ar: description.ar || description,
          de: description.de || description
        };
      }
      
      if (price !== undefined) updateData.price = price;
      if (ingredients !== undefined) {
        updateData.ingredients = {
          en: ingredients.en || ingredients || '',
          ar: ingredients.ar || ingredients || '',
          de: ingredients.de || ingredients || ''
        };
      }
      if (images !== undefined) updateData.images = images;
      if (allergens !== undefined) updateData.allergens = allergens;
      if (nutritionalInfo !== undefined) updateData.nutritionalInfo = nutritionalInfo;
      if (availability !== undefined) updateData.availability = availability;
      if (isNewItem !== undefined) updateData.isNewItem = isNewItem;
      if (isPopular !== undefined) updateData.isPopular = isPopular;
      if (isVegetarian !== undefined) updateData.isVegetarian = isVegetarian;
      if (isVegan !== undefined) updateData.isVegan = isVegan;
      if (isGlutenFree !== undefined) updateData.isGlutenFree = isGlutenFree;
      if (isSpicy !== undefined) updateData.isSpicy = isSpicy;
      if (preparationTime !== undefined) updateData.preparationTime = preparationTime;
      if (sortOrder !== undefined) updateData.sortOrder = sortOrder;

      const product = await Product.findByIdAndUpdate(
        req.params.id,
        updateData,
        { new: true, runValidators: true }
      ).populate('categoryId', 'name');

      if (!product) {
        return res.status(404).json({ error: 'Product not found' });
      }

      res.json({
        message: 'Product updated successfully',
        product
      });
    } catch (err: any) {
      if (err.name === 'ValidationError') {
        const validationErrors = Object.values(err.errors).map((error: any) => error.message);
        return res.status(400).json({ 
          error: 'Validation failed', 
          details: validationErrors 
        });
      }
      res.status(500).json({ error: err.message });
    }
  },

  // Delete product
  remove: async (req: any, res: any) => {
    try {
      const product = await Product.findById(req.params.id);
      
      if (!product) {
        return res.status(404).json({ error: 'Product not found' });
      }

      // Update category product count
      await Category.findByIdAndUpdate(product.categoryId, {
        $inc: { productCount: -1 }
      });

      await Product.findByIdAndDelete(req.params.id);

      res.json({ message: 'Product deleted successfully' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  },

  // Update product availability
  updateAvailability: async (req: any, res: any) => {
    try {
      const { isAvailable, stockQuantity, lowStockThreshold } = req.body;

      const product = await Product.findByIdAndUpdate(
        req.params.id,
        {
          'availability.isAvailable': isAvailable,
          'availability.stockQuantity': stockQuantity,
          'availability.lowStockThreshold': lowStockThreshold
        },
        { new: true }
      );

      if (!product) {
        return res.status(404).json({ error: 'Product not found' });
      }

      res.json({
        message: 'Product availability updated successfully',
        product
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  },

  // Add image to product
  addImage: async (req: any, res: any) => {
    try {
      const { imageUrl } = req.body;

      if (!imageUrl) {
        return res.status(400).json({ error: 'Image URL is required' });
      }

      const product = await Product.findByIdAndUpdate(
        req.params.id,
        { $push: { images: imageUrl } },
        { new: true }
      );

      if (!product) {
        return res.status(404).json({ error: 'Product not found' });
      }

      res.json({
        message: 'Image added successfully',
        product
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  },

  // Remove image from product
  removeImage: async (req: any, res: any) => {
    try {
      const { imageId } = req.params;

      const product = await Product.findByIdAndUpdate(
        req.params.id,
        { $pull: { images: imageId } },
        { new: true }
      );

      if (!product) {
        return res.status(404).json({ error: 'Product not found' });
      }

      res.json({
        message: 'Image removed successfully',
        product
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  },

  // Get products by category
  getByCategory: async (req: any, res: any) => {
    try {
      const { categoryId } = req.params;
      const { page = 1, limit = 20 } = req.query;

      const skip = (Number(page) - 1) * Number(limit);

      const products = await Product.find({ categoryId })
        .populate('categoryId', 'name')
        .sort({ sortOrder: 1, name: 1 })
        .skip(skip)
        .limit(Number(limit));

      const total = await Product.countDocuments({ categoryId });

      res.json({
        products,
        pagination: {
          page: Number(page),
          limit: Number(limit),
          total,
          pages: Math.ceil(total / Number(limit))
        }
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  },

  // Get popular products
  getPopular: async (req: any, res: any) => {
    try {
      const { restaurantId, limit = 10 } = req.query;

      const filter: any = { isPopular: true };
      if (restaurantId) filter.restaurantId = restaurantId;

      const products = await Product.find(filter)
        .populate('categoryId', 'name')
        .sort({ orderCount: -1, rating: -1 })
        .limit(Number(limit));

      res.json(products);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  },

  // Get new products
  getNew: async (req: any, res: any) => {
    try {
      const { restaurantId, limit = 10 } = req.query;

      const filter: any = { isNewItem: true };
      if (restaurantId) filter.restaurantId = restaurantId;

      const products = await Product.find(filter)
        .populate('categoryId', 'name')
        .sort({ createdAt: -1 })
        .limit(Number(limit));

      res.json(products);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }
}; 